# AI Memory / Continuity File

*Internal document — not user-facing. Update this file every time a prompt is run or a phase completes, so context survives across sessions.*

**Last updated:** planning pass (documents 1–6 authored, no build started yet)

## Current Project Name & Scope

Working title TBD (see PRD — candidates: Vitalis / Ascend Coach / Forma, none decided). Personal AI fitness coach web app: meal logging with photo-based calorie estimation, workout planning, habit tracking, progress dashboard, persistent AI coach, voice output. Built personal-first, intended for public open-source release on GitHub/Vercel.

## Current Design Direction

Dribbble fitness dashboard shot (ID 19377958) as the primary visual reference. Font pairing: Comico Regular (bold rounded display, stat numbers/headlines) + Zodiak Regular (serif, editorial/brand moments) + a system sans for body text. Warm cream canvas, coral primary accent, powder-teal secondary panel — see UI/UX Design Brief for the full token table. Stitch-first workflow: design tokens and components come out of Stitch before any code generation.

## Current Stack

Next.js (App Router) + TypeScript + Tailwind CSS, Supabase (Postgres/Auth/Storage), Google AI Studio (Gemini Flash/Flash-Lite) as the hosted LLM, ResponsiveVoice for TTS, hosted on Vercel. AI calls isolated behind one service module for future provider swaps.

## Current Active Constraints

- Free-tier only across every service.
- Hosted AI only — no local inference, no local TTS.
- No doxing — no personal identifiers/contact info/sensitive data in any prompt, log, or output; enforced via RLS + prompt-assembly validation, not left to model judgment.
- Stitch-before-code; sequential phases, no skipping.
- GSD Core used to chunk each phase into smaller execution units; Ralph Loop used to run each chunk to completion before advancing.

## What Has Already Been Decided

- Full feature set: meals (incl. photo analysis), workouts, habits, progress, AI coach, voice.
- Stack choices listed above.
- Phase order: Environment & Setup → Database & Auth → Core Backend/API → Frontend Integration → Polish & Edge Cases → Testing & Deployment.
- Gemini (Google AI Studio) as the default LLM provider, chosen for native multimodal support needed by meal-photo analysis and its permanent no-card free tier.

## What Is Explicitly Forbidden

- Local AI or local TTS of any kind.
- Inventing new product areas beyond what's in the PRD.
- Skipping or reordering implementation phases.
- Adding libraries/tools not confirmed against the (currently missing) `fullcontext_framework.md`.
- Any personal identifier reaching a prompt, log, or generated output.
- Fabricating sensor/wearable data to visually match the Dribbble reference's pulse/temperature/stamina tiles — those must map to real, loggable data instead.

## What Still Needs Clarification

- `fullcontext_framework.md` was referenced in the handoff but never actually supplied — the exact MCP server names, Stitch skill names, and motion library are all unconfirmed until it arrives.
- Final app name and tagline.
- Explicit confirmation of Gemini as the LLM provider (currently a carried-forward recommendation, not yet directly confirmed after this document set).
- Whether "Comico" needs a purchased commercial license, or should be substituted, before the public release.
- Current build status: nothing has been built yet as of this planning pass.

## Completed Checklist

- [x] PRD
- [x] TRD
- [x] App Flow
- [x] UI/UX Design Brief
- [x] Backend Schema
- [x] Implementation Plan
- [x] This memory file

## Remaining Checklist

- [ ] Supply `fullcontext_framework.md` and reconcile tool/skill names across all six documents
- [ ] Phase 1: Environment & Setup
- [ ] Phase 2: Database & Auth
- [ ] Phase 3: Core Backend/API
- [ ] Phase 4: Frontend Integration
- [ ] Phase 5: Polish & Edge Cases
- [ ] Phase 6: Testing & Deployment

## Do Not Forget

- Comico is personal-use-only in its common distribution — resolve licensing before the repo goes public, not after.
- The Dribbble reference's sensor-style stat tiles (pulse, temperature, stamina) have no data source in this app's scope — reuse the tile *pattern*, not the literal metrics, unless wearable integration is explicitly added later.
- No-doxing applies to the AI provider relationship too: free-tier Gemini usage terms allow prompts/outputs to be used to improve Google's models, so keeping personal identifiers out of prompts protects the user on both fronts, not just internally.
